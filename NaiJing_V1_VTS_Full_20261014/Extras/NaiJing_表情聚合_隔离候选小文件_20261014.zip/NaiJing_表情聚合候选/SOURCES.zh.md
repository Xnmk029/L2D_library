# 已实际浏览的原文，2026-10-14

1. VTube Studio 官方：Expressions。
https://github.com/DenchiSoft/VTubeStudio/wiki/Expressions-(a.k.a.-Stickers-or-Emotes)
采纳：Expression Editor 可创建/编辑/切换表达；最新覆盖表达退出可能回到旧项，Add/Multiply 同时累积；参数文件夹来自 cdi3；原生 Expression Groups 的 beta 限制、互斥机制与组淡入淡出优先级。未假定用户已有 beta。

2. VTube Studio 官方：Interaction between Animations, Tracking, Physics, etc.
https://github.com/DenchiSoft/VTubeStudio/wiki/Interaction-between-Animations,-Tracking,-Physics,-etc.
采纳：默认、Idle、追踪、一次动画、Expression、物理的提供者优先级；Multiply 先于 Add；卸载后交回下一级来源。离线组合测试按该顺序，未用 SDK 单表情队列代替宿主多表达语义。

3. VTube Studio 官方 Public API：ExpressionStateRequest / ExpressionActivationRequest。
https://github.com/DenchiSoft/VTubeStudio#requesting-current-expression-state-list
https://github.com/DenchiSoft/VTubeStudio#requesting-activation-or-deactivation-of-expressions
采纳：模型身份和表达状态读回；直接启停指定表达；API 淡入 0..2 秒，淡出沿用激活时的时长。辅助工具保留视觉淡出时间栅栏。

4. Live2D 官方制作教程：Expression Settings and Export。
https://docs.live2d.com/en/cubism-editor-manual/setting-and-exporting-facial-expressions/
采纳：眼开合使用 Multiply 保留自然眨眼；表情有独立淡入淡出设置；可用 Viewer 导出 exp3。没有声称 stock PSD2Live 拥有 Cubism Viewer 的原生表情编辑 UI。

5. Live2D 官方格式规范：exp3 / cdi3。
https://github.com/Live2D/CubismSpecs/blob/master/FileFormats/exp3.json.md
https://github.com/Live2D/CubismSpecs/blob/master/FileFormats/cdi3.json.md
采纳：exp3 参数 Blend、Type、淡入淡出格式；cdi3 的 Id/GroupId/Name 文件夹结构。本候选没有编造模型运行参数。

6. Live2D 创作者べすぱ原教程：VtubeStudio＆Live2D【設定編】表情やホットキーを設定しよう【Vtuber】，2026-01-17。
https://note.com/vesper_illust/n/n77a439059dc2
已读原文。采纳其日常保持追踪、需要时切情绪、预先练习切换和恢复的操作设计。其“窗口失焦不能触发热键”说法不作为本项目结论，热键限制以 VTS 官方文档和实际平台为准；不照抄教程键位覆盖用户设置。

7. VTube Studio 官方：Model File。
https://github.com/DenchiSoft/VTubeStudio/wiki/VTube-Studio-Model-File
官方提醒 vtube JSON 格式没有完整公开文档且手改可能破坏配置，因此没有凭空写未知热键/组字段。现有 ParameterSettings 等配置保持原值，仅副本身份与表达入口另存。

8. websockets 官方连接、变更历史与日志文档。
https://websockets.readthedocs.io/en/stable/reference/asyncio/client.html
https://websockets.readthedocs.io/en/stable/project/changelog.html
https://websockets.readthedocs.io/en/stable/topics/logging.html
已实际浏览。15.0 起可能自动采用系统代理，故显式 proxy=None；另传固定本机 host/port，真实16.0构造器已离线验证拒绝跨来源重定向。连接采用独立禁用 logger，避免全局 DEBUG 记录包含授权信息的帧。运行依赖版本在连接前检查。
