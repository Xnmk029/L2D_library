#!/usr/bin/env python3
"""Generate sidecars only. All model assets and user references stay read-only."""
from pathlib import Path
import json,hashlib,csv,copy,uuid,sys
ROOT=Path(__file__).resolve().parents[1]
BASE=Path('/workspace/shared/l2d-v1-atlas-compact-20261013/build-final/runtime')
OUT=ROOT/'candidate-smallfiles'; EXP=OUT/'expressions'
REF=Path('/workspace/shared/l2d-reference-size-audit-20261013/office_runtime')
VBREF=Path('/workspace/scratch/ac7f0ea43bb9/live2d-sample-test-20261002/work/VBridgerSAMPLEととり')
sys.path.insert(0,'/workspace/shared/l2d-v1-final-assembly-20261012/implementation')
from native_dynamic_qa import read_parameter_metadata
MOC=Path('/workspace/shared/l2d-v1-topology-opt-20261013/candidate/psd2live-preview.moc3')
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
def save(path,obj):path.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
original={p.name:json.loads(p.read_text()) for p in sorted((BASE/'expressions').glob('*.exp3.json'))}; assert len(original)==44
vts=json.loads((BASE/'psd2live-preview.vtube.json').read_text()); model=json.loads((BASE/'psd2live-preview.model3.json').read_text())
meta=read_parameter_metadata(MOC)
names={'Happy':'开心','Sad':'委屈','Surprised':'惊讶','Cold':'冷脸','Cry':'哭泣','Sleepy':'困倦','Dizzy':'眩晕'}
main={}; label={}; paths={}
for mode,title in names.items():
 old=original['V1_Face_'+mode+'.exp3.json']; d=copy.deepcopy(old)
 d['FadeInTime']=d['FadeOutTime']=.25
 # Dedicated manual shape/gate channels can be held. Live capture remains additive.
 remove={'ParamHeartPupils','ParamPeachEyes','ParamMouthFunnel'}
 d['Parameters']=[r for r in d['Parameters'] if r['Id'] not in remove]
 for r in d['Parameters']:
  if r['Id'] in {'ParamBrowLY','ParamBrowRY','ParamMouthForm','ParamEyeSquintL','ParamEyeSquintR'}:
   r['Blend']='Add'
  if r['Id']=='ParamMouthForm':r['Value']={'Happy':.45,'Sad':-.4,'Surprised':-.08,'Cold':-.32,'Cry':-.38,'Sleepy':-.08,'Dizzy':-.12}[mode]
  if r['Id'] in {'ParamEyeSquintL','ParamEyeSquintR'} and mode=='Happy':r['Value']=.30
 if mode in {'Surprised','Dizzy'}:d['Parameters'].append({'Id':'ParamMouthFunnel','Value':.18 if mode=='Surprised' else .12,'Blend':'Add'})
 fn='AGG_Emotion_'+mode+'.exp3.json';main[mode.lower()]=fn;paths[fn]=d;label[fn]='01 情绪 · '+title
for mode,param,title,value,blend in [('Peach','ParamPeachEyes','桃花眼',1,'Overwrite'),('Heart','ParamHeartPupils','爱心瞳孔',1,'Overwrite'),('Tears','ParamFaceCry','泪光叠加',.65,'Add')]:
 fn='AGG_Decor_'+mode+'.exp3.json'; paths[fn]={'Type':'Live2D Expression','FadeInTime':.25,'FadeOutTime':.25,'Parameters':[{'Id':param,'Value':value,'Blend':blend}]};label[fn]='02 独立叠加 · '+title
replaced={x for x in original if x.startswith(('Core_','Emotion_','V1_Face_')) or x in ['FaceDisdain.exp3.json','FaceDisdain_Weak.exp3.json','Disdain_ManualSample.exp3.json','HeartPupils.exp3.json','PeachEyes.exp3.json']}
for fn,d in original.items():
 if fn not in replaced:
  paths[fn]=d;label[fn]=('03 牙型 · ' if fn.startswith('Teeth_') else '04 姿态 · ' if fn.startswith('V1_Pose_') else '05 高级调校 · ')+fn.removesuffix('.exp3.json')
for fn,d in paths.items():save(EXP/fn,d)
assert all(r['Id'] in meta for d in paths.values() for r in d['Parameters'])
assert all(len({r['Id'] for r in d['Parameters']})==len(d['Parameters']) for d in paths.values())
assert all(r['Id'] not in {'ParamHeartPupils','ParamPeachEyes','ParamTeethStyle','ParamMouthOpenY','ParamJawOpenB'} for f in main.values() for r in paths[f]['Parameters'])
model['FileReferences']['Expressions']=[{'Name':label[fn],'File':'expressions/'+fn} for fn in paths]
save(OUT/'psd2live-preview.model3.json',model)
# Independent identity avoids leaking expression state into the user's original model.
vts['ModelID']=uuid.uuid5(uuid.NAMESPACE_URL,'naijing:expression-aggregation:candidate:20261014').hex
vts['Name']='奶鲸 · 表情聚合候选 · 20261014';vts['SavedActiveExpressions']=[];vts['Hotkeys']=[]
save(OUT/'psd2live-preview.vtube.json',vts)
# Real Cubism DisplayInfo folders appear as collapsible folders in current VTS.
# This is display organization only, not a fabricated native ExpressionGroup.
cdi=json.loads((BASE/'psd2live-preview.cdi3.json').read_text())
physics=json.loads((BASE/'psd2live-preview.physics3.json').read_text())
physout={x['Destination']['Id'] for st in physics.get('PhysicsSettings',[]) for x in st.get('Output',[])}
folder_names={'AGG_01_Emotion':'01 情绪预设底层参数','AGG_02_Decor':'02 桃花眼与爱心瞳（各自独立）','AGG_03_Teeth':'03 牙型切换（独立）','AGG_04_Tracking':'04 面捕眼眉嘴（保留追踪）','AGG_05_Body':'05 身体姿态','AGG_06_Advanced':'06 高级强度与门控','AGG_07_Hair':'07 头发与其它','AGG_08_Physics':'08 物理输出（勿设为表情）'}
emotion_ids={'ParamFaceCry','ParamFaceSleepy','ParamFaceDizzy','ParamFaceDisdain','ParamPupilScale','ParamBrowEmotion','ParamEyeWideShape'}
for row in cdi['Parameters']:
 pid=row['Id']
 if pid in physout:g='AGG_08_Physics'
 elif pid in {'ParamPeachEyes','ParamHeartPupils'}:g='AGG_02_Decor'
 elif pid=='ParamTeethStyle':g='AGG_03_Teeth'
 elif pid in emotion_ids:g='AGG_01_Emotion'
 elif any(x in pid for x in ['Strength','Override','Opacity','ColdFaceTrack','WideTrack']):g='AGG_06_Advanced'
 elif any(x in pid for x in ['Mouth','Jaw','Tongue','Cheek','Eye','Brow','Angle']) and not pid.startswith('ParamBody'):g='AGG_04_Tracking'
 elif any(x in pid for x in ['Body','Weight','Knee','Arm','Leg','Coat','Breath']):g='AGG_05_Body'
 else:g='AGG_07_Hair'
 row['GroupId']=g
cdi['Parameters'].sort(key=lambda row:row['GroupId'])
cdi['ParameterGroups']=[{'Id':gid,'GroupId':'','Name':title} for gid,title in folder_names.items()]
save(OUT/'psd2live-preview.cdi3.json',cdi)

new_groups={'emotion':{'label':'主情绪单选','choices':main,'members':list(main.values()),'fade':.25}}
for mode in ['peach','heart','tears']:
 new_groups[mode]={'label':'独立叠加 '+mode,'choices':{'on':'AGG_Decor_'+mode.title()+'.exp3.json'},'members':['AGG_Decor_'+mode.title()+'.exp3.json'],'fade':.25}
new_groups['teeth']={'label':'牙型独立单选','choices':{x:'Teeth_'+x.title()+'.exp3.json' for x in ['normal','shark','canine']},'members':[x for x in paths if x.startswith('Teeth_')],'fade':0.0}
new_groups['body']={'label':'身体姿态独立单选','choices':{x.removeprefix('V1_Pose_').removesuffix('.exp3.json').lower():x for x in paths if x.startswith('V1_Pose_')},'members':[x for x in paths if x.startswith('V1_Pose_')],'fade':.35}
save(ROOT/'expression-groups.json',{'schema':'NaiJing local helper 1; not native VTS ExpressionGroups schema','groups':new_groups,'legacy_conflicts':sorted(replaced),'advanced_controls':[x for x in paths if label[x].startswith('05')]})
save(ROOT/'candidate-model.json',{'modelID':vts['ModelID'],'name':vts['Name'],'status':'isolated candidate; VTS not host-tested'})
rows=[]
for fn,d in original.items():
 target=fn;action='保留，移入高级调校';why='不归入情绪总开关'
 if fn.startswith('V1_Pose_'):action='保留，身体单选组';why='与情绪/牙型/装饰独立'
 if fn.startswith('Teeth_'):action='保留，牙型单选组';why='零淡入淡出；不修改牙型资产'
 if fn in replaced:
  action='默认入口合拢，原文件保留在原模型';why='避免同义入口、Add/Multiply叠加和退出回弹'
  if any(x in fn for x in ['Happy','Sad','Surprised','Cry','Sleepy','Dizzy','Cold']):
   choice=next(x for x in names if x in fn);target=main[choice.lower()]
  elif 'Disdain' in fn:target=main['cold']
  elif 'Heart' in fn:target='AGG_Decor_Heart.exp3.json';why='只改爱心瞳孔，不关闭桃花眼或眩晕'
  elif 'Peach' in fn:target='AGG_Decor_Peach.exp3.json';why='只改桃花眼，不关闭爱心瞳孔或眩晕'
  elif fn=='Emotion_Clear.exp3.json':target='emotion reset（卸载组，不是置零表达）';why='释放所有主情绪修改，交回追踪/默认，保留独立装饰'
 rows.append({'原表达':fn,'新入口':target,'处理':action,'理由':why,'原参数数':len(d['Parameters'])})
with (ROOT/'当前44项到聚合映射.csv').open('w',encoding='utf-8-sig',newline='') as f:
 w=csv.DictWriter(f,fieldnames=rows[0].keys());w.writeheader();w.writerows(rows)
save(ROOT/'proof/original44-inventory.json',{'expressions':original,'hotkey_count':len(json.loads((BASE/'psd2live-preview.vtube.json').read_text())['Hotkeys'])})
# Read real user reference bytes, not screenshot descriptions.
refdata={p.name:json.loads(p.read_text()) for p in sorted((REF/'expressions').glob('*.exp3.json'))}
refv=json.loads((VBREF/'VBridgerSAMPLEととり.vtube.json').read_text());vbfile=next((BASE/'VBridger_Config').glob('*.vbridger'));vb=vbfile.read_bytes();key=b'p3s6v9y$B&E)H@Mc';decoded=json.loads(bytes(x^key[i%len(key)] for i,x in enumerate(vb))[10:])
save(ROOT/'reference/read-reference-evidence.json',{'office_exp3':refdata,'office_exp3_sha256':{p.name:sha(p) for p in (REF/'expressions').glob('*.exp3.json')},'VB_sample_vts_sha256':sha(VBREF/'VBridgerSAMPLEととり.vtube.json'),'VB_sample_expression_count':len(json.loads((VBREF/'VBridgerSAMPLEととり.model3.json').read_text())['FileReferences'].get('Expressions',[])),'VB_sample_hotkeys':refv['Hotkeys'],'VB_sample_mappings':refv['ParameterSettings'],'current_vb_sha256':sha(vbfile),'current_vb_decoded':decoded,'current_vts_mappings':vts['ParameterSettings'],'current_parameters':meta,'missing_blush_parameter':'ParamFaceBlush' not in meta})
save(ROOT/'proof/build.json',{'original44':44,'candidate_expression_count':len(paths),'primary_emotions':7,'independent_decors':3,'teeth':3,'preserved_advanced_or_pose':len(paths)-13,'all_ids_exist':True,'native_hotkeys_created':False,'reason':'No verified current VTS hotkey schema/template. Menu expressions and official API helper are supplied; native groups require beta UI setup.','candidate_model_id':vts['ModelID'],'source_smallfiles_sha256':{str(p.relative_to(BASE)):sha(p) for p in BASE.rglob('*') if p.is_file() and (p.suffix=='.json' or p.suffix=='.vbridger')},'moc_sha256':sha(MOC),'native_project_untouched':True})
print('Built',len(paths),'candidate expressions with 7 primary emotions; baseline unchanged.')
