from pathlib import Path
import os,sys,json,math,re,decimal,ctypes as C,numpy as np
ROOT=Path(__file__).resolve().parents[1];TMP=Path('/tmp/naijing-expression-aggregate-qa');TMP.mkdir(exist_ok=True)
sys.path.insert(0,str(ROOT/'implementation'));from test_candidate import D,P,M
sys.path.insert(0,'/workspace/shared/l2d-v1-final-assembly-20261012/implementation')
from official_core_egl import OfficialRenderer,sig,V,I,F
from native_dynamic_qa import NativeMotionQA,write_qa_motion
model=json.loads((TMP/'qa.model3.json').read_text());refs=model['FileReferences'];refs['DisplayInfo']=os.path.relpath(ROOT/'candidate-smallfiles/psd2live-preview.cdi3.json',TMP)
(TMP/'QAEmpty.exp3.json').write_text(json.dumps({'Type':'Live2D Expression','FadeInTime':.25,'FadeOutTime':.25,'Parameters':[]})+'\n');refs['Expressions'].append({'Name':'QAEmpty','File':'QAEmpty.exp3.json'})
phys=json.load(open('/tmp/naijing-native344/project/original-runtime-sidecars/psd2live-preview.physics3.json'));outputs={x['Destination']['Id'] for st in phys['PhysicsSettings'] for x in st['Output']}
inputs=sorted({p['Id'] for fn in P['emotion']['members'] for p in D[fn]['Parameters']}|{'ParamMouthOpenY','ParamJawOpenB'});default={k:v['default'] for k,v in M.items()}
def inp(t):
 # Linear triangular mouth cycle and long exact-closed eye plateaus, sampled at same FPS.
 eye=0. if t%1.0<.2 else 1.;mouth=round(.65*(1-abs(2*(t%1)-1)),6)
 return default|{'ParamEyeLOpen':eye,'ParamEyeROpen':eye,'ParamMouthOpenY':mouth,'ParamJawOpenB':mouth}
write_qa_motion(TMP/'fades.motion3.json',12.,30,inp,inputs,M,spin_id=None,forbidden_output_ids=outputs)
mp=TMP/'fades.motion3.json';obj=json.loads(mp.read_text());
for curve in obj['Curves']:curve['Segments']=[round(x,6) if isinstance(x,float) else x for x in curve['Segments']]
mp.write_text(json.dumps(obj,separators=(',',':'))+'\n');mp.write_text(re.sub(r'-?\d+(?:\.\d+)?[eE][+-]?\d+',lambda m:format(decimal.Decimal(m.group()),'f'),mp.read_text()))
refs['Motions']={'QA':[{'File':'fades.motion3.json','FadeInTime':0,'FadeOutTime':0}]};path=TMP/'fades.model3.json';path.write_text(json.dumps(model))
r=OfficialRenderer(Path('/workspace/shared/old-v4-rebuild-20261012-audit/core/liblive2d_renderer.so'),path,384,384);q=NativeMotionQA(r,M);expr=sig(r.lib,'Live2D_SetExpression',I,[V,C.c_char_p]);q.start()
names=list(P['emotion']['choices'].values());events={15:names[0],55:names[1],95:names[2],135:names[3],175:names[4],215:names[5],255:names[6],295:'QAEmpty',318:names[0],320:names[1],322:names[4],324:names[6],326:names[3],328:'QAEmpty'}
rows=[];rendered=0
for i in range(360):
 if i in events:assert expr(r.model,events[i].encode())==1
 v=q.update(1/30)
 rows.append({k:v[k] for k in ['ParamEyeLOpen','ParamEyeROpen','ParamMouthOpenY','ParamJawOpenB','ParamManualEmotionOverride','ParamPupilManualOverride','ParamFaceCry','ParamFaceSleepy','ParamFaceDizzy','ParamFaceDisdain','ParamPupilScale','ParamBrowEmotion']})
 if i%10==0:q.draw_current(4.2,0,-2.5046875);rendered+=1
# Model output is sampled after a motion update; compare held sections, not discontinuity frame assumptions.
restored=all(abs(rows[-1][k])<1e-5 for k in ['ParamManualEmotionOverride','ParamPupilManualOverride','ParamFaceCry','ParamFaceSleepy','ParamFaceDizzy','ParamFaceDisdain','ParamPupilScale','ParamBrowEmotion'])
assert restored
assert any(0<v['ParamManualEmotionOverride']<1 for v in rows[15:26])
assert all(min(v['ParamEyeLOpen'] for v in rows[a:a+40])<1e-5 for a in [15,55,95,135,175,215,255])
assert all(max(v['ParamMouthOpenY'] for v in rows[a:a+40])-min(v['ParamMouthOpenY'] for v in rows[a:a+40])>.5 for a in [15,55,95,135,175,215,255])
report={'status':'PASS_REAL_CUBISM_FRAMEWORK_NOT_VTS','updates':360,'rendered_frames':rendered,'gl_errors':0,'events':events,'true_intermediate_fade_values_seen':True,'every_emotion_has_full_eye_closure':True,'every_emotion_mouth_open_range_over_0_5':True,'all_manual_channels_restored_after_clear':restored,'rapid_switch_interval_seconds':2/30,'final_values':rows[-1],'limits':'Framework single-expression queue uses SetExpression; VTS multi-expression stacking and API host were not executed. QAEmpty is a temporary SDK test file, not delivered as a native VTS group reset.'}
(ROOT/'proof/framework-fades.json').write_text(json.dumps(report,indent=2)+'\n');(ROOT/'proof/framework-trace.json').write_text(json.dumps(rows,separators=(',',':'))+'\n');r.close();print(json.dumps(report,indent=2))
