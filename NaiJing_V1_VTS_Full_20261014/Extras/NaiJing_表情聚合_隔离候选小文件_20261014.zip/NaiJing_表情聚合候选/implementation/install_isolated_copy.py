#!/usr/bin/env python3
"""Copy a supported complete runtime to a NEW folder, then install isolated sidecars.
No download, model rebuild, texture edit, source overwrite, symlink delivery, API or login.
"""
import argparse,json,hashlib,shutil,os,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
def check(src,dest):
 if not src.is_dir():raise ValueError('Source runtime directory is missing.')
 if dest.exists():raise ValueError('Destination exists; choose a new empty-name folder. Never overwrite an installed model.')
 if dest==src or src in dest.parents or dest in src.parents:raise ValueError('Source and destination must be separate trees.')
 contract=json.loads((ROOT/'proof/install-contract.json').read_text(encoding='utf-8'))
 for rel,expected in contract['required_smallfiles'].items():
  p=src/rel
  if not p.is_file() or sha(p)!=expected:raise ValueError('Unsupported or modified source sidecar: '+rel)
 moc=src/'psd2live-preview.moc3'
 if not moc.is_file() or sha(moc) not in contract['allowed_moc_sha256']:raise ValueError('Unsupported MOC identity. No files changed.')
 obj=json.loads((src/'psd2live-preview.model3.json').read_text(encoding='utf-8'));refs=obj['FileReferences'];files=[refs['Moc']]+refs['Textures']+[refs[k] for k in ['Physics','DisplayInfo'] if refs.get(k)]+[x['File'] for x in refs.get('Expressions',[])]+[x['File'] for group in refs.get('Motions',{}).values() for x in group]
 for name in files:
  if Path(name).is_absolute() or '..' in Path(name).parts:raise ValueError('Source is a cross-directory QA manifest, not a self-contained runtime.')
  if not (src/name).is_file():raise ValueError('Missing source dependency: '+name)
 return contract

def install(src,dest,dry=False):
 src=Path(src).resolve();dest=Path(dest).resolve();contract=check(src,dest)
 if dry:return {'status':'PRECHECK_ONLY_PASS','source':str(src),'destination':str(dest),'changed_files':0}
 # Copy into a new folder only. A failed copy is left clearly incomplete for inspection.
 dest.mkdir(parents=True,exist_ok=False);marker=dest/'INSTALL_INCOMPLETE.txt';marker.write_text('Incomplete candidate. Do not load until this marker is absent.\n',encoding='utf-8')
 for p in src.iterdir():
  if p.name=='expressions' or p.name.startswith(('02_','05_','06_','07_')):continue
  if p.is_dir():shutil.copytree(p,dest/p.name,symlinks=False)
  else:shutil.copy2(p,dest/p.name,follow_symlinks=True)
 for p in (ROOT/'candidate-smallfiles').iterdir():
  if p.is_dir():shutil.copytree(p,dest/p.name,symlinks=False)
  else:shutil.copy2(p,dest/p.name)
 for name in ['expression-groups.json','candidate-model.json','当前44项到聚合映射.csv','README.zh.md']:
  shutil.copy2(ROOT/name,dest/name)
 (dest/'implementation').mkdir();shutil.copy2(ROOT/'implementation/group_switch.py',dest/'implementation/group_switch.py')
 ref=json.loads((dest/'psd2live-preview.model3.json').read_text(encoding='utf-8'))['FileReferences']
 required=[ref['Moc']]+ref['Textures']+[ref[k] for k in ['Physics','DisplayInfo'] if ref.get(k)]+[x['File'] for x in ref['Expressions']]+[x['File'] for group in ref.get('Motions',{}).values() for x in group]
 if any(not (dest/r).is_file() for r in required):raise ValueError('Incomplete output reference closure; retain marker and inspect.')
 if any(p.is_symlink() for p in dest.rglob('*')):raise ValueError('Output unexpectedly contains symlinks; retain marker.')
 marker.unlink()
 result={'status':'ISOLATED_COPY_INSTALLED','source_unchanged':True,'source':str(src),'destination':str(dest),'expressions':len(ref['Expressions']),'moc_sha256':sha(dest/ref['Moc']),'native_hotkeys_imported':False,'VTS_host_tested':False}
 (dest/'INSTALL_RECEIPT.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');return result
if __name__=='__main__':
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('source');p.add_argument('destination');p.add_argument('--check-only',action='store_true');a=p.parse_args()
 try:print(json.dumps(install(a.source,a.destination,a.check_only),ensure_ascii=False,indent=2))
 except (ValueError,OSError) as e:print('Stopped: '+str(e),file=sys.stderr);sys.exit(1)
