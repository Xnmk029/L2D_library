"""Real Cubism Core + official renderer; expression algebra supplied explicitly (not VTS)."""
import sys,json,ctypes as C,os,hashlib,itertools,math
from pathlib import Path
import numpy as np
from PIL import Image,ImageDraw,ImageFont
ROOT=Path(__file__).resolve().parents[1]; TMP=Path('/tmp/naijing-expression-aggregate-qa');TMP.mkdir(exist_ok=True)
sys.path.insert(0,str(ROOT/'implementation'));from test_candidate import D,P,M,evaluate
sys.path.insert(0,'/workspace/shared/l2d-v1-final-assembly-20261012/implementation');from official_core_egl import OfficialRenderer,sig,V,F
from native_dynamic_qa import NativeMotionQA
src=Path('/workspace/shared/l2d-v1-topology-opt-20261013/candidate/psd2live-preview.model3.json');obj=json.loads(src.read_text());ref=obj['FileReferences']
for k in ['Moc','Physics','DisplayInfo','Pose','UserData']:
 if k in ref:ref[k]=os.path.relpath((src.parent/ref[k]).resolve(),TMP)
ref['Textures']=[os.path.relpath((src.parent/x).resolve(),TMP) for x in ref['Textures']]
ref['Expressions']=[{'Name':f,'File':os.path.relpath(ROOT/'candidate-smallfiles/expressions'/f,TMP)} for f in D];ref['Motions']={}
model=TMP/'qa.model3.json';model.write_text(json.dumps(obj));r=OfficialRenderer(Path('/workspace/shared/old-v4-rebuild-20261012-audit/core/liblive2d_renderer.so'),model,640,640);q=NativeMotionQA(r,M)
base={k:v['default'] for k,v in M.items()};cases=[('Neutral',[],{})]+[(mode.title(),[fn],{}) for mode,fn in P['emotion']['choices'].items()]
cases += [('Cry+Peach+Heart',[P['emotion']['choices']['cry'],'AGG_Decor_Peach.exp3.json','AGG_Decor_Heart.exp3.json'],{}),('Happy+Tears',[P['emotion']['choices']['happy'],'AGG_Decor_Tears.exp3.json'],{}),('Dizzy+Peach+Heart',[P['emotion']['choices']['dizzy'],'AGG_Decor_Peach.exp3.json','AGG_Decor_Heart.exp3.json'],{}),('Sleepy Blink',[P['emotion']['choices']['sleepy']],{'ParamEyeLOpen':0,'ParamEyeROpen':0}),('Happy speaking',[P['emotion']['choices']['happy']],{'ParamMouthOpenY':.65,'ParamJawOpenB':.65}),('Cry speaking',[P['emotion']['choices']['cry']],{'ParamMouthOpenY':.65,'ParamJawOpenB':.65}),('Teeth shark+Happy',[P['emotion']['choices']['happy'],'Teeth_Shark.exp3.json'],{'ParamMouthOpenY':.65,'ParamJawOpenB':.65}),('Teeth canine+Happy',[P['emotion']['choices']['happy'],'Teeth_Canine.exp3.json'],{'ParamMouthOpenY':.65,'ParamJawOpenB':.65})]
images=[];rows=[]
for label,active,values in cases:
 params=evaluate(base|values,active)
 for k,v in params.items():sig(r.lib,'Live2D_SetParameterValue',None,[V,C.c_char_p,F])(r.model,k.encode(),v)
 sig(r.lib,'Live2D_RefreshModel',None,[V])(r.model);image,raw=q.draw_current(4.2,0,-2.5046875)
 bg=np.array([237,240,244]);rgb=np.clip(raw[:,:,:3]+(1-raw[:,:,3:4]/255)*bg,0,255).astype('u1');images.append(Image.fromarray(rgb));rows.append({'label':label,'active':active,'params':params,'pixel_sha256':hashlib.sha256(raw.tobytes()).hexdigest(),'nontransparent_pixels':int((raw[:,:,3]>0).sum())})
 print(label,rows[-1]['nontransparent_pixels'],flush=True)
# Dynamic blink and speech samples: real geometry/render responses to explicit VTS-compatible input values.
for mode in P['emotion']['choices']:
 for i,(eye,mouth) in enumerate([(0,0),(.5,.25),(1,.65)]):
  params=evaluate(base|{'ParamEyeLOpen':eye,'ParamEyeROpen':eye,'ParamMouthOpenY':mouth,'ParamJawOpenB':mouth},[P['emotion']['choices'][mode]])
  for k,v in params.items():sig(r.lib,'Live2D_SetParameterValue',None,[V,C.c_char_p,F])(r.model,k.encode(),v)
  sig(r.lib,'Live2D_RefreshModel',None,[V])(r.model);image,raw=q.draw_current(4.2,0,-2.5046875)
  rows.append({'label':f'{mode}:blink-speech:{i}','eye_value':params['ParamEyeLOpen'],'mouth_value':params['ParamMouthOpenY'],'pixel_sha256':hashlib.sha256(raw.tobytes()).hexdigest(),'nontransparent_pixels':int((raw[:,:,3]>0).sum())})
# One full-body frame verifies framing/unchanged body at neutral.
for k,v in base.items():sig(r.lib,'Live2D_SetParameterValue',None,[V,C.c_char_p,F])(r.model,k.encode(),v)
sig(r.lib,'Live2D_RefreshModel',None,[V])(r.model);image,raw=q.draw_current(1.1,0,0);image.save(ROOT/'proof/fullbody-neutral.png')
# Close-up contact sheets; crop/view framing only, no alteration to model pixels.
cn=['自然','开心','委屈','惊讶','冷脸','哭泣','困倦','眩晕','哭泣 + 桃花眼 + 爱心瞳','开心 + 泪光','眩晕 + 桃花眼 + 爱心瞳','困倦：闭眼输入','开心：张嘴输入','哭泣：张嘴输入','开心 + 鲨鱼牙','开心 + 犬齿']
font=ImageFont.truetype('/usr/share/fonts/opentype/noto/NotoSerifCJK-Bold.ttc',23)
for bi in range(2):
 board=Image.new('RGB',(1020,4*475+48),(244,246,250));draw=ImageDraw.Draw(board)
 draw.text((16,10),'真实 Core 渲染 · 表情聚合候选（非 VTS 实机）',font=font,fill=(30,40,55))
 for j,im in enumerate(images[bi*8:(bi+1)*8]):
  x=(j%2)*510;y=(j//2)*475+48;thumb=im.crop((150,330,490,620)).resize((510,435));board.paste(thumb,(x,y+40));draw.text((x+15,y+7),cn[bi*8+j],font=font,fill=(30,30,40))
 board.save(ROOT/'proof'/('01-emotions.png' if bi==0 else '02-combinations.png'))
report={'renderer':r.info,'model_moc':ref['Moc'],'expression_count':len(D),'frames':len(rows)+1,'gl_errors':0,'status':'REAL_CORE_EXPLICIT_PARAMETERS_NOT_VTS_HOST','rows':rows,'limits':'Expression math is explicit offline evaluation of official VTS multiply-before-add rules, not real host fading or webcam input. Static endpoint/sampled blink-mouth renders are real Core outputs. No source model/texture edits.'}
(ROOT/'proof/core-render.json').write_text(json.dumps(report,indent=2)+'\n');r.close();print('complete',len(rows)+1)
