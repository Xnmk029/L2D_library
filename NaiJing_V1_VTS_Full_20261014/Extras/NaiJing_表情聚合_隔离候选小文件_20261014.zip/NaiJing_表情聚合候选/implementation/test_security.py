"""No-network security regressions. Any attempted TCP connection fails the tests."""
import ast,asyncio,contextlib,importlib.metadata,io,json,logging,os,socket,sys,tempfile,unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
import group_switch as gs
import install_isolated_copy as installer
ROOT=Path(__file__).resolve().parents[1]
DUMMY='TEST_ONLY_FAKE_TOKEN_NEVER_A_REAL_CREDENTIAL'
class FakeWS:
 def __init__(self,token=DUMMY,accepted=True):self.token=token;self.accepted=accepted;self.sent=[]
 async def send(self,text):self.sent.append(json.loads(text))
 async def recv(self):
  p=self.sent[-1];kind=p['messageType'];data={}
  if kind=='AuthenticationTokenRequest':data={'authenticationToken':self.token}
  elif kind=='AuthenticationRequest':data={'authenticated':self.accepted}
  elif kind=='CurrentModelRequest':data={'modelLoaded':True,'modelID':json.loads((ROOT/'candidate-model.json').read_text(encoding='utf-8'))['modelID']}
  elif kind=='ExpressionStateRequest':data={'modelLoaded':True,'modelID':json.loads((ROOT/'candidate-model.json').read_text(encoding='utf-8'))['modelID'],'expressions':[]}
  else:raise AssertionError('No activation is authorized by this test: '+kind)
  return json.dumps({'requestID':p['requestID'],'messageType':kind.removesuffix('Request')+'Response','data':data})
class FakeConnector:
 def __init__(self,ws):self.ws=ws;self.calls=[]
 def __call__(self,uri,**kw):self.calls.append((uri,kw));return self
 async def __aenter__(self):return self.ws
 async def __aexit__(self,*args):return False
class Security(unittest.IsolatedAsyncioTestCase):
 def setUp(self):
  self.net=patch.object(socket.socket,'connect',side_effect=AssertionError('Network forbidden in this test'));self.net.start()
 def tearDown(self):self.net.stop()
 async def run_stub(self,answers,ws):
  c=FakeConnector(ws);out=io.StringIO()
  # Text persistence is forbidden while the controller runs.
  with patch.object(gs,'load_connector',return_value=c),patch('builtins.input',side_effect=answers),patch.object(Path,'write_text',side_effect=AssertionError('No credential/state writes allowed')),contextlib.redirect_stdout(out):
   await gs.run(SimpleNamespace(port=8001))
  return c,out.getvalue()
 async def test_decline_authorize_opens_no_connection(self):
  ws=FakeWS();c,out=await self.run_stub(['NO'],ws);self.assertEqual(c.calls,[]);self.assertEqual(ws.sent,[])
 async def test_vts_token_denial_does_not_auth_or_mutate(self):
  ws=FakeWS(token='')
  with self.assertRaises(gs.SwitchError):await self.run_stub(['AUTHORIZE'],ws)
  self.assertEqual([x['messageType'] for x in ws.sent],['AuthenticationTokenRequest'])
 async def test_vts_auth_denial_does_not_read_or_mutate_model(self):
  ws=FakeWS(accepted=False)
  with self.assertRaises(gs.SwitchError):await self.run_stub(['AUTHORIZE'],ws)
  self.assertEqual([x['messageType'] for x in ws.sent],['AuthenticationTokenRequest','AuthenticationRequest'])
 async def test_connect_constraints_and_no_token_output_or_file(self):
  ws=FakeWS();c,out=await self.run_stub(['AUTHORIZE','NO'],ws)
  uri,kw=c.calls[0];self.assertEqual(uri,'ws://127.0.0.1:8001');self.assertIsNone(kw['proxy']);self.assertEqual(kw['host'],'127.0.0.1');self.assertEqual(kw['port'],8001);self.assertTrue(kw['logger'].disabled);self.assertFalse(kw['logger'].propagate)
  self.assertNotIn(DUMMY,out);self.assertEqual([x['messageType'] for x in ws.sent],['AuthenticationTokenRequest','AuthenticationRequest','CurrentModelRequest','ExpressionStateRequest'])
 async def test_global_debug_cannot_capture_connection_frame(self):
  output=io.StringIO();root=logging.getLogger();old=root.level;h=logging.StreamHandler(output);root.addHandler(h);root.setLevel(logging.DEBUG)
  try:
   logger=gs.connection_options(8001)['logger'];logger.debug('Frame %s',DUMMY);logger.error('Frame %s',DUMMY)
  finally:root.removeHandler(h);root.setLevel(old)
  self.assertNotIn(DUMMY,output.getvalue());self.assertEqual(output.getvalue(),'')
 async def test_actual_websockets_constructor_disables_proxy_and_redirect(self):
  from websockets.asyncio.client import connect
  from websockets.exceptions import InvalidStatus
  from websockets.http11 import Response
  from websockets.datastructures import Headers
  with patch.dict(os.environ,{'http_proxy':'http://proxy.invalid:9999','https_proxy':'http://proxy.invalid:9999','ws_proxy':'http://proxy.invalid:9999','all_proxy':'socks5://proxy.invalid:9999','no_proxy':''},clear=False):
   c=connect('ws://127.0.0.1:8001',**gs.connection_options(8001))
   self.assertIsNone(c.proxy)
   for uri in ['ws://remote.invalid:8001','ws://127.0.0.1:8002','wss://remote.invalid:8001']:
    result=c.process_redirect(InvalidStatus(Response(302,'Found',Headers({'Location':uri}),bytearray())))
    self.assertIsInstance(result,Exception)
 async def test_old_dependency_rejected_before_connection(self):
  with patch.object(importlib.metadata,'version',return_value='14.2'):
   with self.assertRaises(gs.SwitchError):gs.load_connector()
 async def test_supported_dependency_is_modern_client(self):
  from websockets.asyncio.client import connect
  self.assertIs(gs.load_connector(),connect)
 async def test_invalid_port_rejected(self):
  for p in [0,65536,'8001',True]:
   with self.assertRaises(gs.SwitchError):gs.connection_options(p)
 async def test_user_entrypoints_have_explicit_utf8(self):
  for name in ['group_switch.py','install_isolated_copy.py']:
   tree=ast.parse((ROOT/'implementation'/name).read_text(encoding='utf-8'))
   for node in ast.walk(tree):
    if isinstance(node,ast.Call) and isinstance(node.func,ast.Attribute) and node.func.attr in ['read_text','write_text']:
     self.assertTrue(any(k.arg=='encoding' and isinstance(k.value,ast.Constant) and k.value.value=='utf-8' for k in node.keywords),(name,node.lineno))
 async def test_non_utf8_default_locale_equivalent(self):
  original_open=Path.open
  def cp936_open(path,mode='r',buffering=-1,encoding=None,errors=None,newline=None):
   if 'b' not in mode and encoding is None:encoding='cp936'
   return original_open(path,mode,buffering,encoding,errors,newline)
  with patch.object(Path,'open',cp936_open):
   c,out=await self.run_stub(['NO'],FakeWS());self.assertEqual(c.calls,[])
   with tempfile.TemporaryDirectory() as tmp:
    result=installer.install('/workspace/shared/l2d-v1-atlas-compact-20261013/build-final/runtime',Path(tmp)/'新候选',dry=True)
    self.assertEqual(result['changed_files'],0)
if __name__=='__main__':
 suite=unittest.defaultTestLoader.loadTestsFromModule(sys.modules[__name__]);r=unittest.TextTestRunner(verbosity=2).run(suite)
 (ROOT/'proof/security-tests.json').write_text(json.dumps({'tests':r.testsRun,'passed':r.wasSuccessful(),'failures':len(r.failures),'errors':len(r.errors),'network_calls':0,'real_credentials_used':False,'websockets_version':importlib.metadata.version('websockets'),'scope':'Stub VTS protocol; real client constructor/proxy/redirect logic; logging suppression; explicit UTF-8 and cp936-default-equivalent reads. No VTS host execution.'},indent=2)+'\n',encoding='utf-8');sys.exit(not r.wasSuccessful())
