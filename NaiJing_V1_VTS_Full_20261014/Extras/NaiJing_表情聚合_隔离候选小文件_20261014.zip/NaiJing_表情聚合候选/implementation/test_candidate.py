import asyncio,copy,itertools,json,sys,unittest,time
from pathlib import Path
sys.path.insert(0,str(Path(__file__).parent))
from group_switch import GroupController,SwitchError
ROOT=Path(__file__).resolve().parents[1];PLAN=json.loads((ROOT/'expression-groups.json').read_text());P=PLAN['groups']
D={f.name:json.loads(f.read_text()) for f in (ROOT/'candidate-smallfiles/expressions').glob('*.json')}
M=json.loads((ROOT/'reference/read-reference-evidence.json').read_text())['current_parameters']
def evaluate(base,active):
 out=dict(base)
 for fn in active:
  for p in D[fn]['Parameters']:
   if p['Blend']=='Overwrite':out[p['Id']]=p['Value']
 for blend in ['Multiply','Add']:
  for fn in active:
   for p in D[fn]['Parameters']:
    if p['Blend']==blend:out[p['Id']]=out[p['Id']]*p['Value'] if blend=='Multiply' else out[p['Id']]+p['Value']
 return {k:max(M[k]['min'],min(M[k]['max'],v)) for k,v in out.items()}
class Mock:
 def __init__(self):self.id='candidate';self.rows={f:{'file':f,'active':False} for f in D};self.log=[];self.fail=None;self.ignore=False;self.changed_model=False
 async def request(self,kind,data):
  self.log.append((kind,copy.deepcopy(data),time.monotonic()));await asyncio.sleep(0)
  if self.fail==kind:raise SwitchError('mock denial')
  if kind=='CurrentModelRequest':return {'modelLoaded':True,'modelID':self.id}
  if kind=='ExpressionStateRequest':return {'modelLoaded':True,'modelID':self.id,'expressions':list(self.rows.values())}
  if kind=='ExpressionActivationRequest':
   if not self.ignore:self.rows[data['expressionFile']]['active']=data['active']
   if self.changed_model:self.id='other'
   return {}
class Contract(unittest.TestCase):
 def test_all_ids(self):
  for d in D.values():
   self.assertEqual(len({p['Id'] for p in d['Parameters']}),len(d['Parameters']))
   for p in d['Parameters']:self.assertIn(p['Id'],M)
 def test_main_does_not_own_independent(self):
  for f in P['emotion']['members']:
   self.assertFalse({p['Id'] for p in D[f]['Parameters']}&{'ParamHeartPupils','ParamPeachEyes','ParamTeethStyle','ParamMouthOpenY','ParamJawOpenB'})
 def test_blink_mouth_grid(self):
  for f,eye,mouth in itertools.product(P['emotion']['members'],[0,.1,.5,1],[0,.2,.6,1]):
   base={k:v['default'] for k,v in M.items()};base.update(ParamEyeLOpen=eye,ParamEyeROpen=eye,ParamMouthOpenY=mouth,ParamJawOpenB=mouth)
   out=evaluate(base,[f]);factor=next(p['Value'] for p in D[f]['Parameters'] if p['Id']=='ParamEyeLOpen')
   self.assertAlmostEqual(out['ParamEyeLOpen'],eye*factor);self.assertEqual(out['ParamMouthOpenY'],mouth);self.assertEqual(out['ParamJawOpenB'],mouth)
 def test_independent_combinations(self):
  base={k:v['default'] for k,v in M.items()}
  for f,peach,heart,tooth in itertools.product(P['emotion']['members'],[False,True],[False,True],P['teeth']['members']):
   active=[f,tooth]+(['AGG_Decor_Peach.exp3.json'] if peach else [])+(['AGG_Decor_Heart.exp3.json'] if heart else [])
   out=evaluate(base,active);self.assertEqual(out['ParamHeartPupils'],float(heart));self.assertEqual(out['ParamPeachEyes'],float(peach));self.assertEqual(out['ParamTeethStyle'],D[tooth]['Parameters'][0]['Value'])
 def test_tears_clamped_composition(self):
  base={k:v['default'] for k,v in M.items()}
  for f in P['emotion']['members']:
   out=evaluate(base,[f,'AGG_Decor_Tears.exp3.json']);self.assertEqual(out['ParamFaceCry'],1 if 'Cry.' in f else .65)
 def test_native_fade_rules(self):
  for g in P.values():
   for fn in g['choices'].values():self.assertEqual(D[fn]['FadeInTime'],g['fade']);self.assertEqual(D[fn]['FadeOutTime'],g['fade'])
 def test_no_blush_claim_or_shadow_parameter(self):
  self.assertNotIn('ParamFaceBlush',M)
  for fn in P['emotion']['members']:
   self.assertFalse(any('shadow' in p['Id'].lower() for p in D[fn]['Parameters']))
class Controller(unittest.IsolatedAsyncioTestCase):
 def setUp(self):
  self.mock=Mock();self.plan=copy.deepcopy(P)
  for g in self.plan.values():g['fade']=.002
  self.c=GroupController(self.mock.request,self.plan,'candidate',PLAN['legacy_conflicts'],settle_timeout=.04,poll_interval=.001,settle_margin=.001)
 async def test_each_ordered_pair_and_reset(self):
  for a,b in itertools.product(P['emotion']['choices'],repeat=2):
   await self.c.switch('emotion',a);await self.c.switch('emotion',b)
   active={f for f,x in self.mock.rows.items() if x['active']};self.assertEqual(active,{P['emotion']['choices'][b]})
   await self.c.switch('emotion','reset');self.assertFalse(any(x['active'] for x in self.mock.rows.values()))
 async def test_rapid_concurrent_switches_serialized(self):
  choices=list(P['emotion']['choices'])*2
  await asyncio.gather(*(self.c.switch('emotion',x) for x in choices))
  self.assertEqual([f for f,x in self.mock.rows.items() if x['active']],[P['emotion']['choices'][choices[-1]]])
 async def test_decor_and_teeth_survive_emotion_reset(self):
  for g,x in [('peach','on'),('heart','on'),('tears','on'),('teeth','shark'),('emotion','cry'),('emotion','reset')]:await self.c.switch(g,x)
  self.assertTrue(all(self.mock.rows[P[g]['choices'][x]]['active'] for g,x in [('peach','on'),('heart','on'),('tears','on'),('teeth','shark')]))
 async def test_idempotent(self):
  await self.c.switch('emotion','happy');before=len(self.mock.log);r=await self.c.switch('emotion','happy');self.assertFalse(r['changed']);self.assertFalse(any(k=='ExpressionActivationRequest' for k,_,_ in self.mock.log[before:]))
 async def test_preexisting_stops(self):
  self.mock.rows[P['emotion']['choices']['cry']]['active']=True
  with self.assertRaises(SwitchError):await self.c.switch('emotion','happy')
  self.assertFalse(any(k=='ExpressionActivationRequest' for k,_,_ in self.mock.log))
 async def test_legacy_stops(self):
  self.mock.rows['V1_Face_Happy.exp3.json']={'file':'V1_Face_Happy.exp3.json','active':True}
  with self.assertRaises(SwitchError):await self.c.switch('emotion','happy')
 async def test_missing_target_stops(self):
  del self.mock.rows[P['emotion']['choices']['happy']]
  with self.assertRaises(SwitchError):await self.c.switch('emotion','happy')
 async def test_model_identity(self):
  self.mock.id='baseline'
  with self.assertRaises(SwitchError):await self.c.switch('emotion','happy')
 async def test_mid_switch_model_change(self):
  self.mock.changed_model=True
  with self.assertRaises(SwitchError):await self.c.switch('emotion','happy')
  before=len(self.mock.log)
  with self.assertRaises(SwitchError):await self.c.switch('emotion','sad')
  self.assertEqual(before,len(self.mock.log))
 async def test_activation_denial_no_retry(self):
  self.mock.fail='ExpressionActivationRequest'
  with self.assertRaises(SwitchError):await self.c.switch('emotion','happy')
  self.assertEqual(sum(k=='ExpressionActivationRequest' for k,_,_ in self.mock.log),1)
 async def test_ignored_state_timeout(self):
  self.mock.ignore=True
  with self.assertRaises(SwitchError):await self.c.switch('emotion','happy')
 async def test_cancel_before_no_action(self):
  e=asyncio.Event();e.set();self.c.cancel_event=e
  with self.assertRaises(asyncio.CancelledError):await self.c.switch('emotion','happy')
  self.assertEqual(self.mock.log,[])
 async def test_invalid_choice_recoverable(self):
  with self.assertRaises(SwitchError):await self.c.switch('emotion','missing')
  await self.c.switch('emotion','happy')
 async def test_fade_fence(self):
  self.plan['emotion']['fade']=.015
  await self.c.switch('emotion','happy');await self.c.switch('emotion','sad')
  acts=[(d,t) for k,d,t in self.mock.log if k=='ExpressionActivationRequest'];self.assertGreaterEqual(acts[2][1]-acts[1][1],.015)
  self.assertNotIn('fadeTime',acts[1][0])
if __name__=='__main__':
 suite=unittest.defaultTestLoader.loadTestsFromModule(sys.modules[__name__]);r=unittest.TextTestRunner(verbosity=2).run(suite)
 (ROOT/'proof/tests.json').write_text(json.dumps({'tests':r.testsRun,'failures':len(r.failures),'errors':len(r.errors),'passed':r.wasSuccessful(),'layer':'offline contract and mocked official API; not VTS-host execution','ordered_emotion_pairs':49,'rapid_concurrent_switches':14,'blink_mouth_samples':112,'independent_combo_samples':84},indent=2)+'\n');sys.exit(not r.wasSuccessful())
