#!/usr/bin/env python3
"""Optional official-API controller. Never imported network-side effects; localhost only."""
import argparse,asyncio,json,sys,uuid,logging,importlib.metadata
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
class SwitchError(RuntimeError):pass
def load_connector():
 """Require the modern client with explicit proxy opt-out; never auto-install."""
 try:
  installed=importlib.metadata.version('websockets')
  major=int(installed.split('.',1)[0])
 except (importlib.metadata.PackageNotFoundError,ValueError):
  raise SwitchError('Requires Python websockets >=15 from PyPI. No dependency was installed and no connection was opened.')
 if major<15:raise SwitchError('Requires websockets >=15 for explicit proxy=None. No connection opened; use VTS menus or update the dependency yourself.')
 try:from websockets.asyncio.client import connect
 except ImportError:raise SwitchError('Modern websockets client unavailable; no connection opened.')
 return connect

def connection_options(port):
 if type(port) is not int or not 1<=port<=65535:raise SwitchError('Port must be 1..65535.')
 # An unregistered, permanently disabled logger cannot inherit global DEBUG/frame logging.
 # Do not reconfigure the application's root logger or global websockets loggers.
 logger=logging.Logger('naijing.private.websocket',level=logging.CRITICAL+1)
 logger.disabled=True;logger.propagate=False;logger.addHandler(logging.NullHandler())
 return {'proxy':None,'logger':logger,'host':'127.0.0.1','port':port,'open_timeout':10,'max_size':2**22}

class GroupController:
 def __init__(self,request,plan,model_id,legacy=(),settle_timeout=3.,poll_interval=.025,settle_margin=.05,cancel_event=None):
  self.request=request;self.plan=plan;self.model_id=model_id;self.legacy=set(legacy)
  self.settle_timeout=settle_timeout;self.poll_interval=poll_interval;self.margin=settle_margin;self.cancel_event=cancel_event
  self.expected={g:None for g in plan};self.owned_fades={};self.lock=asyncio.Lock();self.failed=False
 def check(self):
  if self.failed:raise SwitchError('Controller stopped after an uncertain/error result; inspect VTS and restart.')
  if self.cancel_event and self.cancel_event.is_set():raise asyncio.CancelledError('Cancelled; inspect VTS state.')
 async def state(self):
  self.check();m=await self.request('CurrentModelRequest',{})
  if not m.get('modelLoaded') or m.get('modelID')!=self.model_id:raise SwitchError('Expected isolated candidate model is not loaded.')
  self.check();d=await self.request('ExpressionStateRequest',{'details':False})
  if not d.get('modelLoaded') or d.get('modelID')!=self.model_id:raise SwitchError('Model changed; stopped.')
  rows=d.get('expressions');
  if not isinstance(rows,list):raise SwitchError('Missing expression state; stopped.')
  s={x['file']:x for x in rows}
  if len(s)!=len(rows):raise SwitchError('Ambiguous duplicate expression filenames; stopped.')
  if any(x.get('active') for f,x in s.items() if f in self.legacy):raise SwitchError('Legacy expression is active; inspect VTS, clear it and wait for fade-out before restart.')
  self.check();return s
 async def wait(self,members,want,not_before):
  deadline=asyncio.get_running_loop().time()+self.settle_timeout
  while True:
   s=await self.state();active={f for f,x in s.items() if f in members and x.get('active')};now=asyncio.get_running_loop().time()
   if active==want and now>=not_before:return
   if now>=deadline:raise SwitchError('State did not settle; inspect VTS. No retry.')
   await asyncio.sleep(self.poll_interval)
 async def switch(self,group,choice):
  if group not in self.plan:raise SwitchError('Unknown group.')
  g=self.plan[group];target=None if choice in {'reset','off'} else g['choices'].get(choice)
  if choice not in {'reset','off'} and target is None:raise SwitchError('Unknown choice.')
  # One lock for the connection also prevents overlapping websocket recv calls.
  async with self.lock:
   self.check()
   try:return await self._switch(group,g,target)
   except BaseException:self.failed=True;raise
 async def _switch(self,group,g,target):
  s=await self.state();members=set(g['members'])
  if target and target not in s:raise SwitchError('Target expression absent; nothing changed.')
  active={f for f,x in s.items() if f in members and x.get('active')};old=self.expected[group]
  if active!=(set() if old is None else {old}):raise SwitchError('Pre-existing/external group change; nothing changed. Inspect VTS and restart after fades.')
  if (not active and target is None) or active=={target}:return {'group':group,'active':target,'changed':False}
  fade=max((self.owned_fades[f] for f in active),default=0.)
  for f in sorted(active):
   await self.state();self.check();await self.request('ExpressionActivationRequest',{'expressionFile':f,'active':False})
  await self.wait(members,set(),asyncio.get_running_loop().time()+fade+self.margin if active else 0)
  for f in active:self.owned_fades.pop(f,None)
  if target:
   s=await self.state()
   if target not in s or any(x.get('active') for f,x in s.items() if f in members):raise SwitchError('State changed before activation; target not activated.')
   fade=float(g['fade']);self.check()
   await self.request('ExpressionActivationRequest',{'expressionFile':target,'active':True,'fadeTime':fade})
   self.owned_fades[target]=fade
   await self.wait(members,{target},asyncio.get_running_loop().time()+fade+self.margin)
  self.expected[group]=target
  return {'group':group,'active':target,'changed':True}
async def run(args):
 connector=load_connector()
 plan=json.loads((ROOT/'expression-groups.json').read_text(encoding='utf-8'));binding=json.loads((ROOT/'candidate-model.json').read_text(encoding='utf-8'))
 print('VTS must load the isolated expression-aggregation candidate. This plugin controls expressions only.')
 print('Authorization grants VTS plugin access. The token stays in memory, never saved or printed. Revoke it in VTS when unwanted.')
 if (await asyncio.to_thread(input,'Type AUTHORIZE to request VTS permission, otherwise quit: ')).strip()!='AUTHORIZE':return
 async with connector('ws://127.0.0.1:'+str(args.port),**connection_options(args.port)) as ws:
  async def request(kind,data):
   rid=uuid.uuid4().hex
   await ws.send(json.dumps({'apiName':'VTubeStudioPublicAPI','apiVersion':'1.0','requestID':rid,'messageType':kind,'data':data}))
   deadline=asyncio.get_running_loop().time()+(120 if kind=='AuthenticationTokenRequest' else 10)
   while True:
    remaining=deadline-asyncio.get_running_loop().time()
    if remaining<=0:raise SwitchError('Response uncertain; no retry. Inspect VTS.')
    try:p=json.loads(await asyncio.wait_for(ws.recv(),remaining))
    except asyncio.TimeoutError:raise SwitchError('Response uncertain; no retry. Inspect VTS.')
    if p.get('requestID')!=rid:continue
    if p.get('messageType')=='APIError':raise SwitchError('VTS denied the request. Inspect the VTS permission/status screen; response contents are not logged.')
    if p.get('messageType')!=kind.removesuffix('Request')+'Response':raise SwitchError('Unexpected response; stopped.')
    return p.get('data',{})
  identity={'pluginName':'NaiJing Expression Aggregation Candidate','pluginDeveloper':'NaiJing Local Tools'}
  d=await request('AuthenticationTokenRequest',identity);token=d.get('authenticationToken')
  if not token:raise SwitchError('No token; stopped.')
  auth=await request('AuthenticationRequest',{**identity,'authenticationToken':token});del token,d
  if not auth.get('authenticated'):raise SwitchError('Authentication declined; stopped.')
  ctl=GroupController(request,plan['groups'],binding['modelID'],plan['legacy_conflicts'])
  s=await ctl.state();members={f for g in plan['groups'].values() for f in g['members']}
  if any(x.get('active') for f,x in s.items() if f in members):raise SwitchError('Turn off managed groups in VTS and wait for visible fades before restarting.')
  print('Do not mix native hotkeys/beta groups/other controllers while this helper runs. Wait for all existing fades to finish.')
  if (await asyncio.to_thread(input,'Type READY when confirmed: ')).strip()!='READY':return
  print('Commands: emotion happy/sad/surprised/cold/cry/sleepy/dizzy/reset; peach on/off; heart on/off; tears on/off; teeth normal/shark/canine/reset; body '+','.join(plan['groups']['body']['choices'])+'/reset; quit')
  print('reset removes only that group. quit does not clear expressions; reset wanted groups first.')
  while True:
   words=(await asyncio.to_thread(input,'Expression> ')).strip().lower().split()
   if words in [['quit'],['exit']]:return
   if len(words)!=2:print('Enter a group and choice.');continue
   try:print(json.dumps(await ctl.switch(*words),ensure_ascii=False))
   except SwitchError as e:
    print(str(e))
    if ctl.failed:return
if __name__=='__main__':
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--port',type=int,default=8001);a=p.parse_args()
 if not 1<=a.port<=65535:p.error('Port must be 1..65535')
 try:asyncio.run(run(a))
 except (SwitchError,OSError,KeyboardInterrupt) as e:print(str(e),file=sys.stderr);sys.exit(1)
